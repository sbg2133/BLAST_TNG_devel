% roach2_8tap_wide/XSG_core_config
roach2_8tap_wide_XSG_core_config_type         = 'xps_xsg';
roach2_8tap_wide_XSG_core_config_param        = '';

% roach2_8tap_wide/QDR_LUT/qdr0
roach2_8tap_wide_QDR_LUT_qdr0_type         = 'xps_qdr';
roach2_8tap_wide_QDR_LUT_qdr0_param        = '';
roach2_8tap_wide_QDR_LUT_qdr0_addr_start   = hex2dec('0200_0000');
roach2_8tap_wide_QDR_LUT_qdr0_addr_end     = hex2dec('027F_FFFF');

% roach2_8tap_wide/QDR_LUT/qdr1
roach2_8tap_wide_QDR_LUT_qdr1_type         = 'xps_qdr';
roach2_8tap_wide_QDR_LUT_qdr1_param        = '';
roach2_8tap_wide_QDR_LUT_qdr1_addr_start   = hex2dec('0280_0000');
roach2_8tap_wide_QDR_LUT_qdr1_addr_end     = hex2dec('02FF_FFFF');

% roach2_8tap_wide/QDR_LUT/snap_qdr/bram
roach2_8tap_wide_QDR_LUT_snap_qdr_bram_type         = 'xps_bram';
roach2_8tap_wide_QDR_LUT_snap_qdr_bram_param        = '4096';
roach2_8tap_wide_QDR_LUT_snap_qdr_bram_ip_name      = 'bram_if';
roach2_8tap_wide_QDR_LUT_snap_qdr_bram_addr_start   = hex2dec('01000000');
roach2_8tap_wide_QDR_LUT_snap_qdr_bram_addr_end     = hex2dec('01003FFF');

% roach2_8tap_wide/QDR_LUT/snap_qdr/ctrl
roach2_8tap_wide_QDR_LUT_snap_qdr_ctrl_type         = 'xps_sw_reg';
roach2_8tap_wide_QDR_LUT_snap_qdr_ctrl_param        = 'in';
roach2_8tap_wide_QDR_LUT_snap_qdr_ctrl_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_QDR_LUT_snap_qdr_ctrl_addr_start   = hex2dec('01004000');
roach2_8tap_wide_QDR_LUT_snap_qdr_ctrl_addr_end     = hex2dec('010040FF');

% roach2_8tap_wide/QDR_LUT/snap_qdr/status
roach2_8tap_wide_QDR_LUT_snap_qdr_status_type         = 'xps_sw_reg';
roach2_8tap_wide_QDR_LUT_snap_qdr_status_param        = 'out';
roach2_8tap_wide_QDR_LUT_snap_qdr_status_ip_name      = 'opb_register_simulink2ppc';
roach2_8tap_wide_QDR_LUT_snap_qdr_status_addr_start   = hex2dec('01004100');
roach2_8tap_wide_QDR_LUT_snap_qdr_status_addr_end     = hex2dec('010041FF');

% roach2_8tap_wide/QDR_LUT/we_qdr
roach2_8tap_wide_QDR_LUT_we_qdr_type         = 'xps_sw_reg';
roach2_8tap_wide_QDR_LUT_we_qdr_param        = 'in';
roach2_8tap_wide_QDR_LUT_we_qdr_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_QDR_LUT_we_qdr_addr_start   = hex2dec('01004200');
roach2_8tap_wide_QDR_LUT_we_qdr_addr_end     = hex2dec('010042FF');

% roach2_8tap_wide/accum_snap/bram
roach2_8tap_wide_accum_snap_bram_type         = 'xps_bram';
roach2_8tap_wide_accum_snap_bram_param        = '2048';
roach2_8tap_wide_accum_snap_bram_ip_name      = 'bram_if';
roach2_8tap_wide_accum_snap_bram_addr_start   = hex2dec('01006000');
roach2_8tap_wide_accum_snap_bram_addr_end     = hex2dec('01007FFF');

% roach2_8tap_wide/accum_snap/ctrl
roach2_8tap_wide_accum_snap_ctrl_type         = 'xps_sw_reg';
roach2_8tap_wide_accum_snap_ctrl_param        = 'in';
roach2_8tap_wide_accum_snap_ctrl_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_accum_snap_ctrl_addr_start   = hex2dec('01008000');
roach2_8tap_wide_accum_snap_ctrl_addr_end     = hex2dec('010080FF');

% roach2_8tap_wide/accum_snap/status
roach2_8tap_wide_accum_snap_status_type         = 'xps_sw_reg';
roach2_8tap_wide_accum_snap_status_param        = 'out';
roach2_8tap_wide_accum_snap_status_ip_name      = 'opb_register_simulink2ppc';
roach2_8tap_wide_accum_snap_status_addr_start   = hex2dec('01008100');
roach2_8tap_wide_accum_snap_status_addr_end     = hex2dec('010081FF');

% roach2_8tap_wide/adc_mkid
roach2_8tap_wide_adc_mkid_type         = 'xps_adc_mkid';
roach2_8tap_wide_adc_mkid_param        = '';
roach2_8tap_wide_adc_mkid_ip_name      = 'adc_mkid_interface';

% roach2_8tap_wide/adc_snap/bram
roach2_8tap_wide_adc_snap_bram_type         = 'xps_bram';
roach2_8tap_wide_adc_snap_bram_param        = '2048';
roach2_8tap_wide_adc_snap_bram_ip_name      = 'bram_if';
roach2_8tap_wide_adc_snap_bram_addr_start   = hex2dec('0100A000');
roach2_8tap_wide_adc_snap_bram_addr_end     = hex2dec('0100BFFF');

% roach2_8tap_wide/adc_snap/ctrl
roach2_8tap_wide_adc_snap_ctrl_type         = 'xps_sw_reg';
roach2_8tap_wide_adc_snap_ctrl_param        = 'in';
roach2_8tap_wide_adc_snap_ctrl_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_adc_snap_ctrl_addr_start   = hex2dec('0100C000');
roach2_8tap_wide_adc_snap_ctrl_addr_end     = hex2dec('0100C0FF');

% roach2_8tap_wide/adc_snap/status
roach2_8tap_wide_adc_snap_status_type         = 'xps_sw_reg';
roach2_8tap_wide_adc_snap_status_param        = 'out';
roach2_8tap_wide_adc_snap_status_ip_name      = 'opb_register_simulink2ppc';
roach2_8tap_wide_adc_snap_status_addr_start   = hex2dec('0100C100');
roach2_8tap_wide_adc_snap_status_addr_end     = hex2dec('0100C1FF');

% roach2_8tap_wide/adc_snap_trig
roach2_8tap_wide_adc_snap_trig_type         = 'xps_sw_reg';
roach2_8tap_wide_adc_snap_trig_param        = 'in';
roach2_8tap_wide_adc_snap_trig_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_adc_snap_trig_addr_start   = hex2dec('0100C200');
roach2_8tap_wide_adc_snap_trig_addr_end     = hex2dec('0100C2FF');

% roach2_8tap_wide/bins
roach2_8tap_wide_bins_type         = 'xps_sw_reg';
roach2_8tap_wide_bins_param        = 'in';
roach2_8tap_wide_bins_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_bins_addr_start   = hex2dec('0100C300');
roach2_8tap_wide_bins_addr_end     = hex2dec('0100C3FF');

% roach2_8tap_wide/chan_bins/bram
roach2_8tap_wide_chan_bins_bram_type         = 'xps_bram';
roach2_8tap_wide_chan_bins_bram_param        = '1024';
roach2_8tap_wide_chan_bins_bram_ip_name      = 'bram_if';
roach2_8tap_wide_chan_bins_bram_addr_start   = hex2dec('0100D000');
roach2_8tap_wide_chan_bins_bram_addr_end     = hex2dec('0100DFFF');

% roach2_8tap_wide/chan_bins/ctrl
roach2_8tap_wide_chan_bins_ctrl_type         = 'xps_sw_reg';
roach2_8tap_wide_chan_bins_ctrl_param        = 'in';
roach2_8tap_wide_chan_bins_ctrl_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_chan_bins_ctrl_addr_start   = hex2dec('0100E000');
roach2_8tap_wide_chan_bins_ctrl_addr_end     = hex2dec('0100E0FF');

% roach2_8tap_wide/chan_bins/status
roach2_8tap_wide_chan_bins_status_type         = 'xps_sw_reg';
roach2_8tap_wide_chan_bins_status_param        = 'out';
roach2_8tap_wide_chan_bins_status_ip_name      = 'opb_register_simulink2ppc';
roach2_8tap_wide_chan_bins_status_addr_start   = hex2dec('0100E100');
roach2_8tap_wide_chan_bins_status_addr_end     = hex2dec('0100E1FF');

% roach2_8tap_wide/chan_select
roach2_8tap_wide_chan_select_type         = 'xps_sw_reg';
roach2_8tap_wide_chan_select_param        = 'in';
roach2_8tap_wide_chan_select_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_chan_select_addr_start   = hex2dec('0100E200');
roach2_8tap_wide_chan_select_addr_end     = hex2dec('0100E2FF');

% roach2_8tap_wide/dac_mkid1
roach2_8tap_wide_dac_mkid1_type         = 'xps_dac_mkid';
roach2_8tap_wide_dac_mkid1_param        = '';
roach2_8tap_wide_dac_mkid1_ip_name      = 'dac_mkid_interface';

% roach2_8tap_wide/dac_reset
roach2_8tap_wide_dac_reset_type         = 'xps_sw_reg';
roach2_8tap_wide_dac_reset_param        = 'in';
roach2_8tap_wide_dac_reset_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_dac_reset_addr_start   = hex2dec('0100E300');
roach2_8tap_wide_dac_reset_addr_end     = hex2dec('0100E3FF');

% roach2_8tap_wide/dds_shift
roach2_8tap_wide_dds_shift_type         = 'xps_sw_reg';
roach2_8tap_wide_dds_shift_param        = 'in';
roach2_8tap_wide_dds_shift_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_dds_shift_addr_start   = hex2dec('0100E400');
roach2_8tap_wide_dds_shift_addr_end     = hex2dec('0100E4FF');

% roach2_8tap_wide/fft_shift
roach2_8tap_wide_fft_shift_type         = 'xps_sw_reg';
roach2_8tap_wide_fft_shift_param        = 'in';
roach2_8tap_wide_fft_shift_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_fft_shift_addr_start   = hex2dec('0100E500');
roach2_8tap_wide_fft_shift_addr_end     = hex2dec('0100E5FF');

% roach2_8tap_wide/fft_snap/bram
roach2_8tap_wide_fft_snap_bram_type         = 'xps_bram';
roach2_8tap_wide_fft_snap_bram_param        = '1024';
roach2_8tap_wide_fft_snap_bram_ip_name      = 'bram_if';
roach2_8tap_wide_fft_snap_bram_addr_start   = hex2dec('0100F000');
roach2_8tap_wide_fft_snap_bram_addr_end     = hex2dec('0100FFFF');

% roach2_8tap_wide/fft_snap/ctrl
roach2_8tap_wide_fft_snap_ctrl_type         = 'xps_sw_reg';
roach2_8tap_wide_fft_snap_ctrl_param        = 'in';
roach2_8tap_wide_fft_snap_ctrl_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_fft_snap_ctrl_addr_start   = hex2dec('01010000');
roach2_8tap_wide_fft_snap_ctrl_addr_end     = hex2dec('010100FF');

% roach2_8tap_wide/fft_snap/status
roach2_8tap_wide_fft_snap_status_type         = 'xps_sw_reg';
roach2_8tap_wide_fft_snap_status_param        = 'out';
roach2_8tap_wide_fft_snap_status_ip_name      = 'opb_register_simulink2ppc';
roach2_8tap_wide_fft_snap_status_addr_start   = hex2dec('01010100');
roach2_8tap_wide_fft_snap_status_addr_end     = hex2dec('010101FF');

% roach2_8tap_wide/load_bins
roach2_8tap_wide_load_bins_type         = 'xps_sw_reg';
roach2_8tap_wide_load_bins_param        = 'in';
roach2_8tap_wide_load_bins_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_load_bins_addr_start   = hex2dec('01010200');
roach2_8tap_wide_load_bins_addr_end     = hex2dec('010102FF');

% roach2_8tap_wide/mixerout/bram
roach2_8tap_wide_mixerout_bram_type         = 'xps_bram';
roach2_8tap_wide_mixerout_bram_param        = '32768';
roach2_8tap_wide_mixerout_bram_ip_name      = 'bram_if';
roach2_8tap_wide_mixerout_bram_addr_start   = hex2dec('01020000');
roach2_8tap_wide_mixerout_bram_addr_end     = hex2dec('0103FFFF');

% roach2_8tap_wide/mixerout/ctrl
roach2_8tap_wide_mixerout_ctrl_type         = 'xps_sw_reg';
roach2_8tap_wide_mixerout_ctrl_param        = 'in';
roach2_8tap_wide_mixerout_ctrl_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_mixerout_ctrl_addr_start   = hex2dec('01080000');
roach2_8tap_wide_mixerout_ctrl_addr_end     = hex2dec('010800FF');

% roach2_8tap_wide/mixerout/status
roach2_8tap_wide_mixerout_status_type         = 'xps_sw_reg';
roach2_8tap_wide_mixerout_status_param        = 'out';
roach2_8tap_wide_mixerout_status_ip_name      = 'opb_register_simulink2ppc';
roach2_8tap_wide_mixerout_status_addr_start   = hex2dec('01080100');
roach2_8tap_wide_mixerout_status_addr_end     = hex2dec('010801FF');

% roach2_8tap_wide/one_GbE
roach2_8tap_wide_one_GbE_type         = 'xps_onegbe';
roach2_8tap_wide_one_GbE_param        = '';
roach2_8tap_wide_one_GbE_ip_name      = 'gbe_udp';
roach2_8tap_wide_one_GbE_addr_start   = hex2dec('01084000');
roach2_8tap_wide_one_GbE_addr_end     = hex2dec('01087FFF');

% roach2_8tap_wide/overflow
roach2_8tap_wide_overflow_type         = 'xps_sw_reg';
roach2_8tap_wide_overflow_param        = 'out';
roach2_8tap_wide_overflow_ip_name      = 'opb_register_simulink2ppc';
roach2_8tap_wide_overflow_addr_start   = hex2dec('01088000');
roach2_8tap_wide_overflow_addr_end     = hex2dec('010880FF');

% roach2_8tap_wide/pps
roach2_8tap_wide_pps_type         = 'xps_gpio';
roach2_8tap_wide_pps_param        = '';
roach2_8tap_wide_pps_ip_name      = 'diffgpio_ext2simulink';

% roach2_8tap_wide/pps_start
roach2_8tap_wide_pps_start_type         = 'xps_sw_reg';
roach2_8tap_wide_pps_start_param        = 'in';
roach2_8tap_wide_pps_start_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_pps_start_addr_start   = hex2dec('01088100');
roach2_8tap_wide_pps_start_addr_end     = hex2dec('010881FF');

% roach2_8tap_wide/rawfftbin/bram
roach2_8tap_wide_rawfftbin_bram_type         = 'xps_bram';
roach2_8tap_wide_rawfftbin_bram_param        = '65536';
roach2_8tap_wide_rawfftbin_bram_ip_name      = 'bram_if';
roach2_8tap_wide_rawfftbin_bram_addr_start   = hex2dec('010C0000');
roach2_8tap_wide_rawfftbin_bram_addr_end     = hex2dec('010FFFFF');

% roach2_8tap_wide/rawfftbin/ctrl
roach2_8tap_wide_rawfftbin_ctrl_type         = 'xps_sw_reg';
roach2_8tap_wide_rawfftbin_ctrl_param        = 'in';
roach2_8tap_wide_rawfftbin_ctrl_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_rawfftbin_ctrl_addr_start   = hex2dec('01100000');
roach2_8tap_wide_rawfftbin_ctrl_addr_end     = hex2dec('011000FF');

% roach2_8tap_wide/rawfftbin/status
roach2_8tap_wide_rawfftbin_status_type         = 'xps_sw_reg';
roach2_8tap_wide_rawfftbin_status_param        = 'out';
roach2_8tap_wide_rawfftbin_status_ip_name      = 'opb_register_simulink2ppc';
roach2_8tap_wide_rawfftbin_status_addr_start   = hex2dec('01100100');
roach2_8tap_wide_rawfftbin_status_addr_end     = hex2dec('011001FF');

% roach2_8tap_wide/rx_ack
roach2_8tap_wide_rx_ack_type         = 'xps_sw_reg';
roach2_8tap_wide_rx_ack_param        = 'in';
roach2_8tap_wide_rx_ack_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_rx_ack_addr_start   = hex2dec('01100200');
roach2_8tap_wide_rx_ack_addr_end     = hex2dec('011002FF');

% roach2_8tap_wide/rx_rst
roach2_8tap_wide_rx_rst_type         = 'xps_sw_reg';
roach2_8tap_wide_rx_rst_param        = 'in';
roach2_8tap_wide_rx_rst_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_rx_rst_addr_start   = hex2dec('01100300');
roach2_8tap_wide_rx_rst_addr_end     = hex2dec('011003FF');

% roach2_8tap_wide/start_dac
roach2_8tap_wide_start_dac_type         = 'xps_sw_reg';
roach2_8tap_wide_start_dac_param        = 'in';
roach2_8tap_wide_start_dac_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_start_dac_addr_start   = hex2dec('01100400');
roach2_8tap_wide_start_dac_addr_end     = hex2dec('011004FF');

% roach2_8tap_wide/sync/accum_len
roach2_8tap_wide_sync_accum_len_type         = 'xps_sw_reg';
roach2_8tap_wide_sync_accum_len_param        = 'in';
roach2_8tap_wide_sync_accum_len_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_sync_accum_len_addr_start   = hex2dec('01100500');
roach2_8tap_wide_sync_accum_len_addr_end     = hex2dec('011005FF');

% roach2_8tap_wide/sync/accum_reset
roach2_8tap_wide_sync_accum_reset_type         = 'xps_sw_reg';
roach2_8tap_wide_sync_accum_reset_param        = 'in';
roach2_8tap_wide_sync_accum_reset_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_sync_accum_reset_addr_start   = hex2dec('01100600');
roach2_8tap_wide_sync_accum_reset_addr_end     = hex2dec('011006FF');

% roach2_8tap_wide/tx_destip
roach2_8tap_wide_tx_destip_type         = 'xps_sw_reg';
roach2_8tap_wide_tx_destip_param        = 'in';
roach2_8tap_wide_tx_destip_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_tx_destip_addr_start   = hex2dec('01100700');
roach2_8tap_wide_tx_destip_addr_end     = hex2dec('011007FF');

% roach2_8tap_wide/tx_destport
roach2_8tap_wide_tx_destport_type         = 'xps_sw_reg';
roach2_8tap_wide_tx_destport_param        = 'in';
roach2_8tap_wide_tx_destport_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_tx_destport_addr_start   = hex2dec('01100800');
roach2_8tap_wide_tx_destport_addr_end     = hex2dec('011008FF');

% roach2_8tap_wide/tx_rst
roach2_8tap_wide_tx_rst_type         = 'xps_sw_reg';
roach2_8tap_wide_tx_rst_param        = 'in';
roach2_8tap_wide_tx_rst_ip_name      = 'opb_register_ppc2simulink';
roach2_8tap_wide_tx_rst_addr_start   = hex2dec('01100900');
roach2_8tap_wide_tx_rst_addr_end     = hex2dec('011009FF');

% OPB to OPB bridge added at 0x1080000
OPB_to_OPB_bridge_added_at_0x1080000_type         = 'xps_opb2opb';
OPB_to_OPB_bridge_added_at_0x1080000_param        = '';

% OPB to OPB bridge added at 0x1100000
OPB_to_OPB_bridge_added_at_0x1100000_type         = 'xps_opb2opb';
OPB_to_OPB_bridge_added_at_0x1100000_param        = '';

